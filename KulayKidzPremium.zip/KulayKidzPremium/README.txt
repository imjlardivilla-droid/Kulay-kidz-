KULAYKIDZ PREMIUM-STYLE STARTER

Files:
- index.html: the full app (gallery, categories, coloring tools, undo/redo, erase, reset, save PNG)
- manifest.json: basic install metadata

HOW TO UPDATE ON GITHUB USING ANDROID:
1. Open github.com and sign in.
2. Open your KulayKidz repository.
3. Open index.html. Tap the pencil/Edit icon.
4. Select all existing code and replace it with the full contents of this new index.html file. On Android, easiest option is to download this project ZIP, extract it, open index.html in a text editor, copy all, then paste into GitHub's editor.
5. Tap Commit changes and confirm.
6. Make sure Settings > Pages is configured to deploy from your main branch and /(root).
7. Open your GitHub Pages URL and refresh. If the old version remains, try Chrome menu > Settings > Privacy and security > Delete browsing data > Cached images and files.

NOTE: This is a free, client-side starter app. It does not include paid subscriptions, accounts, cloud sync, or server storage. Drawings are simple original SVG line art and can be expanded later.
